# -*- coding: utf-8 -*-
"""
/***************************************************************************
    GP
 ***************************************************************************/
"""
import os

from PyQt5 import uic
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QListWidget
# объявляем класс из другого модуля
from .GP_class_func import Mrgp
from . import mrgp_panels

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'GP.ui'))

class GPcreatorDialog(QtWidgets.QDialog, FORM_CLASS):
    """Get dialog class"""
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(GPcreatorDialog, self).__init__(parent)
        self.setupUi(self)

        self.iface = iface

        # подключаемся к комбобоксу и получаем текущий слой
        # self.mMapLayerComboBox.
        self.mMapLayerComboBox.layerChanged.connect(self.layer_changed)

        # получаем текущий слой в свойства объекта
        self.cur_lr = self.mMapLayerComboBox.currentLayer()

        # вешаем функцию на кнопки
        self.rnBtn.clicked.connect(self.run_btn)
        self.btnupdatefields.clicked.connect(self.update_fields)

        # инициируем выпадающий список полей
        self.mFieldComboBox.setLayer(self.cur_lr)
        self.mFieldComboBox_2.setLayer(self.cur_lr)

        # путь к рабочему столу
        self.desktop = os.path.join(os.path.join(os.path.expanduser('~')), 'Desktop')

        # резервируем переменную для объекта класса
        self.class_gp = None

        # резервируем переменную для объекта класса
        self.mrgp_panels = None
        self.path_to_fldr = ''

    def run_btn(self):
        """main func"""
        self.cur_lr = self.mMapLayerComboBox.currentLayer()
        # print(f'LAYER: {self.cur_lr.name()}')
        # print(f'{self.desktop}')

        col_for_filter = self.mFieldComboBox.currentText()
        # print(f'COL_FOR_FILTER: {col_for_filter}')

        val_field_filt = self.edite_txt_filter.text()  # значение колонки по которому фильтруем таблицу
        # print(f'FILTER: {val_field_filt}')

        column_for_name_files = self.mFieldComboBox_2.currentText()  # колонка для имён файлов
        # print(f'CLM_FILE_NAMES: {column_for_name_files}')

        pth_rslt = self.mQgsFileWidget.filePath() + '\\'  # путь куда сохранять
        # print(f'PATH_FOR_SAVE: {pth_rslt}')

        # инициируем класс из другого модуля
        self.class_gp = Mrgp(self.iface, pth_rslt, col_for_filter, val_field_filt, column_for_name_files)
        self.class_gp.main_func(self.cur_lr)

        # инициируем клас из другого модуля дабы не писать функции в этом листинге
        self.mrgp_panels = mrgp_panels.mrgp_panels(self.iface)
        self.mrgp_panels.dir_path = pth_rslt   # получаем путь куда сохраняем результаты
        self.mrgp_panels.displaye_custom_message_bar(title='MSG', message=f'Результаты сохранены - {pth_rslt}')



    def layer_changed(self):
        layer = self.mMapLayerComboBox.currentLayer()
        self.cur_lr = self.mMapLayerComboBox.currentLayer()
        # print(f'{self.cur_lr.name()}')

    def update_fields(self):
        self.cur_lr = self.mMapLayerComboBox.currentLayer()
        self.mFieldComboBox.setLayer(self.cur_lr)
        self.mFieldComboBox_2.setLayer(self.cur_lr)