from qgis.PyQt.QtWidgets import QAction
import json
import ast


# from qgis.core import *
from processing import Processing as pr
from qgis.core import (QgsApplication,
                       QgsJsonExporter,
                       QgsProject,
                       QgsCoordinateTransform,
                       QgsCoordinateReferenceSystem)

""" ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- /"""
"""                                  ЗАМЕНИТЬ ЗНАЧЕНИЯ НИЖЕ                                                 """
""" ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- /"""

ISH_DT = dict(
    PATH_FOR_RESULT=r"C:\!_Python\_799_word_excel\BORIS_enemy\rslt\\",      # 1
    FILTER_COLUMN=r"prim",                                                  # 2
    FILTER_VAL=r"20220623",                                                 # 3
    COLUMN_NAME_FOR_FILE=r"name"                                            # 4
)

""" ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- / ---- /"""

APU_SRC = r"+proj=tmerc +lat_0=55.66666666667 +lon_0=37.5 +k=1 +x_0=12 +y_0=14 +ellps=bessel +towgs84=316.151,78.924,589.65,-1.57273,2.69209,2.34693,8.4507 +units=m +no_defs"

class Mrgp:
    def __init__(self, iface, pth_rslt, col_for_filter, val_field_filt, column_for_name_files):
        self.iface = iface
        self.prj = QgsProject.instance()
        self.all_lrs = self.prj.instance().mapLayers()
        self.sel_lrs = None
        self.path_for_result = pth_rslt
        self.filter_column = col_for_filter
        self.filter_val = val_field_filt
        self.column_name_for_file =column_for_name_files
        self.changes_names = []

    def translitezator(self, old_name: str) -> dict:
        # символы замен - что на что меняем
        legend = {
            '»': '_',
            '«': '_',
            '—': '_',
            ']': '_',
            '[': '_',
            '}': '_',
            '{': '_',
            '&': '_',
            ')': '_',
            '(': '_',
            '^': '_',
            '$': '_',
            '#': '_',
            '~': '_',
            '-': '_',
            '"': '_',
            '@': '_',
            '!': '_',
            '%': '_',
            '.': '_',
            '+': '_',
            '>': '_',
            '<': '_',
            '?': '_',
            '*': '_',
            '|': '_',
            ';': '_',
            ':': '_',
            '/': '_',
            '№': 'N',
            ' ': '_',
            ',': '',
            'а': 'a',
            'б': 'b',
            'в': 'v',
            'г': 'g',
            'д': 'd',
            'е': 'e',
            'ё': 'yo',
            'ж': 'zh',
            'з': 'z',
            'и': 'i',
            'й': 'y',
            'к': 'k',
            'л': 'l',
            'м': 'm',
            'н': 'n',
            'о': 'o',
            'п': 'p',
            'р': 'r',
            'с': 's',
            'т': 't',
            'у': 'u',
            'ф': 'f',
            'х': 'h',
            'ц': 'c',
            'ч': 'ch',
            'ш': 'sh',
            'щ': 'shch',
            'ъ': '',
            'ы': 'y',
            'ь': '',
            'э': 'e',
            'ю': 'yu',
            'я': 'ya',
            'А': 'A',
            'Б': 'B',
            'В': 'V',
            'Г': 'G',
            'Д': 'D',
            'Е': 'E',
            'Ё': 'Yo',
            'Ж': 'Zh',
            'З': 'Z',
            'И': 'I',
            'Й': 'Y',
            'К': 'K',
            'Л': 'L',
            'М': 'M',
            'Н': 'N',
            'О': 'O',
            'П': 'P',
            'Р': 'R',
            'С': 'S',
            'Т': 'T',
            'У': 'U',
            'Ф': 'F',
            'Х': 'H',
            'Ц': 'Ts',
            'Ч': 'Ch',
            'Ш': 'Sh',
            'Щ': 'Shch',
            'Ъ': '',
            'Ы': 'Y',
            'Ь': '',
            'Э': 'E',
            'Ю': 'Yu',
            'Я': 'Ya',
        }

        # инициируем словарь для результатов
        dict_for_replace = {}

        # до начала замены символов загоняем старое имя в новое (чтоб потом проверить изменения)
        file_new = old_name
        for i, j in legend.items():
            file_new = file_new.replace(i, j)

        while file_new.find("__") > 0:
            file_new = file_new.replace("__", "_")

        if file_new.endswith("_"):
            file_new = file_new[:-1]

        dict_for_replace[old_name] = file_new

        return dict_for_replace

    def save_as_geojson_reproject_feat(self, layer):
        crs = QgsCoordinateReferenceSystem()
        crs.createFromProj4(APU_SRC)
        in_crs = crs
        out_crs = QgsCoordinateReferenceSystem(4326)
        xform = QgsCoordinateTransform(in_crs, out_crs, QgsProject.instance())

        def lmbd(feature):
            """  перепроецируем отдельно поле геометрии данного объекта """
            geometry = feature.geometry()
            geometry.transform(xform)
            feature.setGeometry(geometry)
            return feature

        exporter = QgsJsonExporter()

        json_string = [(
                exporter.exportFeature(lmbd(f)),
                lmbd(f)[self.column_name_for_file],
                                             ) for f in layer.selectedFeatures()]

        for i, r in enumerate(json_string):
            # ['bbox', 'geometry', 'id', 'properties', 'type']
            # print(f"{r[0]}\n\n")
            # print(f"{r[1]}\n\n")

            print(f"{r}\n\n")

            # print(f"{type(r[0])} \n\n")

            jsn = ast.literal_eval(r[0].replace("null", "None"))
            # jsn = ast.literal_eval(r[0])
            fl_nm = self.translitezator(r[1])
            geojson = {
                "type": "FeatureCollection",
                "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
                "features": [{
                    "type": "Feature",
                    "properties": jsn['properties'],
                    "geometry": jsn['geometry']
                }]
            }

            with open(f'{self.path_for_result}\\{list(fl_nm.values())[0]}.geojson', 'w') as outfile:
                # json.dump(geojson, outfile)
                json.dump(geojson, outfile, ensure_ascii=False)

            self.changes_names.append(
                str(list(fl_nm.keys())[0]) + "->" + str(list(fl_nm.values())[0]) + ".geojson \n")

    def select_feature_by_column_val(self, lr):
        """ делаем выборку в слое """
        LAYERS = lr
        alg_name = "qgis:selectbyattribute"     # алгоритм
        params = \
            {
                'INPUT': LAYERS,
                'FIELD': self.filter_column,
                'OPERATOR': 0,
                'VALUE': self.filter_val,
                'METHOD': 0
            }
        alg = QgsApplication.processingRegistry().algorithmById(alg_name)
        # layer = processing.run(alg, params)['OUTPUT']
        layer = pr.runAlgorithm(alg, params)['OUTPUT']

    def pack_selected_lrs(self, path_out):
        '''упаковываем выбранные слои в gpkg и сохраняем по пути'''
        LAYERS = self.sel_lrs
        alg_name = "native:package"
        params = \
            {
                'LAYERS': LAYERS,
                'OUTPUT': path_out,
                'OVERWRITE': True,
                'SAVE_STYLES': True,
                'SAVE_METADATA': True,
                'SELECTED_FEATURES_ONLY': False
            }
        alg = QgsApplication.processingRegistry().algorithmById(alg_name)
        # layer = processing.run(alg, params)['OUTPUT']
        layer = pr.runAlgorithm(alg, params)['OUTPUT']

    def main_func(self, lr):
        """ делаем выборку в каждом слое """
        self.select_feature_by_column_val(lr)
        self.save_as_geojson_reproject_feat(lr)

        with open(f'{self.path_for_result}\\files_name.txt', 'w', encoding='utf8') as outfile:
            outfile.write('\n'.join(str(line.replace("->", "  --->  \n")) for line in self.changes_names))
            outfile.write('\n')

    def main(self):
        ''' делаем выборку в каждом слое '''
        self.sel_lrs = self.iface.layerTreeView().selectedLayers()
        for layer in self.sel_lrs:
            self.select_feature_by_column_val(layer)
            self.save_as_geojson_reproject_feat(layer)

        with open(f'{self.path_for_result}\\files_name.txt', 'w', encoding='utf8') as outfile:
            outfile.write('\n'.join(str(line.replace("->", "  --->  \n")) for line in self.changes_names))
            outfile.write('\n')

if __name__ == "__console__":
    mcls = Mrgp(iface)
    action = QAction('BORIS_GPKG_TO_JSON')
    action.triggered.connect(mcls.main)
    #action.setIcon(QIcon(icon_path))
    iface.addToolBarIcon(action)