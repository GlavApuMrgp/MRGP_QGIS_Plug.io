# -*- coding: utf-8 -*-
"""
/***************************************************************************

 mrgp_panels

/***************************************************************************/

"""

# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    from .mrgp_panels import mrgp_panels
    return mrgp_panels(iface)
