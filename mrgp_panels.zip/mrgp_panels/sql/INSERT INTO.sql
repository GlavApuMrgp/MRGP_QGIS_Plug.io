INSERT INTO trash.building_pr ( 
    "id", 
    "tip_obj",
    "name_obj",
    "et_naz",
    "tip_obj_eng", 
    "h_m",
    "hz_m",
    "t_from_contents",
    "prim",
    "status_terr",
    "category_terr",
    "link_terr",
    "filter",
    "geom",
    "act",
    user_name,
    date_act, 
    layer_name, 
    host_ip)
VALUES(
    OLD."id", 
    OLD."tip_obj",
    OLD."name_obj",
    OLD."et_naz",
    OLD."tip_obj_eng", 
    OLD."h_m",
    OLD."hz_m",
    OLD."t_from_contents",
    OLD."prim",
    OLD."status_terr",
    OLD."category_terr",
    OLD."link_terr",
    OLD."filter",
    OLD."geom",
    TG_OP, -- действие, на которое среагировал триггер
    current_user, -- текущее имя пользователя
    now(), -- текущее время
    TG_TABLE_NAME, -- имя таблицы где сработал триггер
    inet_client_addr()); -- ip address у кого сработал триггер