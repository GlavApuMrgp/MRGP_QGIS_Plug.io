# -*- coding: utf-8 -*-
"""
/***************************************************************************

 mrgp panels

 ***************************************************************************/
"""
import os.path
import sys
import shutil
import inspect
import pathlib
import datetime
import os
import socket
from qgis.core import (Qgis, QgsMapLayerType, QgsUnitTypes, QgsSettings, QgsApplication, QgsJsonExporter, QgsFeatureRequest,
                       QgsProject, QgsCoordinateTransform, QgsCoordinateReferenceSystem, QgsField, QgsExpression,
                       QgsExpressionContextUtils, QgsExpressionContext, QgsProcessingFeedback, QgsProcessingContext,
                       QgsProcessingAlgRunnerTask, QgsProcessing, NULL, QgsFeature, QgsGeometry)

from PyQt5.QtCore import QSettings, QTranslator, qVersion, QCoreApplication, QVariant
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction, QMenu, QToolButton, QToolBar, QFileDialog, QPushButton, QMessageBox

from qgis.gui import QgsMessageBar

import psycopg2

""" инициализируем processing """
import processing
from processing.core.Processing import Processing

Processing.initialize

""" Импортируем иконки для кнопок из файла resources.py """
from .resources import *

""" Импортируем диалоговые окна """
from .GPKG_creator_dialog import GPKG_creatorDialog  # импорт окна для экспорт в GPKG
from .GPcreatorDialog import GPcreatorDialog  # импорт окна для запуска GP функций

""" Импортируем дополнительные скрипты """
from .rectangleAreaTool import RectangleAreaTool

from PyQt5.QtWidgets import QApplication

APU_SRC = r"+proj=tmerc +lat_0=55.66666666667 +lon_0=37.5 +k=1 +x_0=12 +y_0=14 +ellps=bessel +towgs84=316.151,78.924,589.65,-1.57273,2.69209,2.34693,8.4507 +units=m +no_defs"
DB_MRGP = 'USER_SUPER_DB'
NAME_PLUG = 'mrgp_panels'
DB_IP_MRGP = '000.00.00.000'
Port_MRGP = '0000'
USER_NAME = 'program_user'
PASS_USER = 'user_program'


# """ ЛОГИРОВАНИЕ """
# try:
#     from MY_LOGGING.logfunc import Loger
#     # from MY_LOGGING.logfunc import MyDec
#     # ct = Loger()
#     # vot = MyDec
#     print(f"ВКЛЮЧЕНО")
# except:
#     print(f"Логгирование отключено")
# PLUG_PATH = os.path.dirname(__file__)  # путь к плагину
# now_name = datetime.datetime.now().strftime(r"%Y-%m-%d_%H-%M-%S")  # получаем текущее значение времени
# PLUG_PATH = os.path.dirname(__file__)  # путь к плагину
# cur_path = f'{PLUG_PATH}/LOG_Folder/'  # добавляем каталог для логирования
# os.makedirs(os.path.dirname(f'{cur_path}'), exist_ok=True)  # создаем каталог если не существует
# abs_path = os.path.abspath(cur_path)  # получаем абсолютный путь
#
# # предварительно очищаем каталог от прошлых логов
# for filename in os.listdir(abs_path):
#     filepath = os.path.join(abs_path, filename)
#     try:
#         shutil.rmtree(filepath)
#     except OSError:
#         os.remove(filepath)
#
# path_join = os.path.join(abs_path, f'LOG_{now_name}.txt')  # в имя лог файла добавляем дату и время
# logging.basicConfig(filename=f'{path_join}', filemode="w", level=logging.INFO)  # инициализация логирования




class mrgp_panels:
    s = QgsSettings()

    def __init__(self, iface):
        self.prj = QgsProject.instance()  # инициализируем проект в аттрибут класса
        self.tmp_rslt = None  # для временного хранения результатов
        self.tmp_lr = None  # для временного хранения слоя
        self.lrs = None  # для временного хранения слоёв
        self.cont_ext = QgsProcessingContext()
        self.feed_back = QgsProcessingFeedback()

        """ путь к каталогу """
        self.dir_path = ''

        """ связываем qgis iface и наш класс """
        self.iface = iface

        """ инициализируем класс с функциями """
        self.mrgp_func = mrgp_func

        """ инициализируем каталог plugin """
        self.plugin_dir = os.path.dirname(__file__)

        """ инициализируем локальный путь """
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            f"{NAME_PLUG}"+'_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '0.0.1':
                QCoreApplication.installTranslator(self.translator)

        """ создание диалоговых окон """
        self.dlg_GP = GPcreatorDialog(self.iface)

        """ объявление аттрибутов plugin """
        self.actions = []  # список для хранения функций
        self.menu = self.tr(f"{NAME_PLUG}")  # назначаем заголовок для меню плагина
        self.toolbar = self.iface.addToolBar(f"{NAME_PLUG}")  # добавляем в пространство имён наше меню
        self.toolbar.setObjectName(f"{NAME_PLUG}")  # присваиваем имя нашей панельке

    """ для правильной связи контекста вызова функций """
    def tr(self, message):
        return QCoreApplication.translate(f"{NAME_PLUG}", message)

    """ функция для добавления функций в Qgis с определенными свойствами """
    def add_action(
            self,
            icon_path,  # путь к иконке если необходима
            text,  # название для кнопки
            callback,  # вызываемая функция
            enabled_flag=True,  # доступная для вызова пользователем
            add_to_menu=True,  # добавить в меню
            add_to_toolbar=True,  # добавить в панель
            status_tip=None,  # свойство содержит подсказку о состоянии действия
            whats_this=None,
            parent=None,  # область (окно) видимости куда добавляем функцию
            checkable=True  # свойство чтоб иконка на панели была как кнопка со свойством нажата и отжата
    ):
        """ вяжем функцию, иконку, название с тригером вызова """
        if icon_path is not None:
            icon = QIcon(icon_path)
        else:
            icon = QIcon()
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        """ устанавливаем свойство для функции """
        if status_tip is not None:
            action.setStatusTip(status_tip)

        """ устанавливаем свойство для функции """
        if whats_this is not None:
            action.setWhatsThis(whats_this)

        action.setToolTip(text)

        """ чтоб иконка на панели была как кнопка со свойством нажата и отжата """
        action.setCheckable(checkable)

        """ добавляем функцию к панели """
        if add_to_toolbar:
            self.toolbar.addAction(action)

        """ добавляем плагин в меню """
        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        """ добавляем функцию к списку с функциями в переменную класса """
        self.actions.append(action)

        return action

    def initGui(self):
        """ЗАРЕЗЕВРИРОВАННАЯ Функция вызывается при инициализации plugin в Qgis"""

        """ добавляем обычные кнопки иконки в меню """
        self.add_symply_button_with_icon_in_menu()

        """ добавляем иконку в меню с popup выпадающим списком функций """
        self.add_popup_menu()

        # """!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ЗАГЛУШИЛ КНОПКУ ПРИНЯТЫХ РЕШЕНИЙ   !!!!!!!!!!!!! """
        # """ добавляем иконку в меню с popup выпадающим списком функций для выгрузки """
        # self.add_popup_pr()

    def add_symply_button_with_icon_in_menu(self):
        """ добавляем обычные кнопки иконки в меню """
        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_LD.png'
        self.rectangleAction = self.add_action(
            icon_path=iconpth,
            text=self.tr(u'Экспорт в *.gpkg для ЛД'),
            callback=self.runRectangle,
            parent=self.iface.mainWindow(),
            add_to_toolbar=True)


        self.rectangleAreaTool = RectangleAreaTool(self.iface.mapCanvas(), self.rectangleAction)
        self.rectangleAreaTool.rectangleCreated.connect(self.run)

        # iconpth = ':/plugins/mrgp_panels/logo_svg.png'
        # self.add_action(
        #     icon_path=iconpth,
        #     text=self.tr(u'В буфер скопировали *.svg выбранного объекта'),
        #     callback=self.test_print,
        #     parent=self.iface.mainWindow(),
        #     checkable=False,
        #     add_to_toolbar=True)


        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_GP.png'
        self.add_action(
            icon_path=iconpth,
            text=self.tr(u'Градполитика'),
            callback=self.run_GP,
            parent=self.iface.mainWindow(),
            checkable=False,
            add_to_toolbar=True)

        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_wkt.png'
        self.add_action(
            icon_path=iconpth,
            text=self.tr(u'В буфере wkt выбранного объекта'),
            callback=self.getwkt,
            parent=self.iface.mainWindow(),
            checkable=False,
            add_to_toolbar=True)

        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_tmp.png'
        self.add_action(
            icon_path=iconpth,
            text=self.tr(u'Создаём временные слои из выбранных'),
            callback=self.run_create_tmp_lr,
            parent=self.iface.mainWindow(),
            checkable=False,
            add_to_toolbar=True)

        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_json_export.png'
        self.add_action(
            icon_path=iconpth,
            text=self.tr(u'Экспорт в *.geojson, crs 4326'),
            callback=self.run_export_to_geojson_wgs,
            parent=self.iface.mainWindow(),
            checkable=False,
            add_to_toolbar=True)

    def add_popup_menu(self):
        """ добавляем кнопки иконки в меню с выпадающим списком функций """
        # тупо иконка в меню (функция будет вызываться при нажатии на кнопку (не на треугольник))
        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_Fn.png'
        self.action0 = self.add_action(
            icon_path=iconpth,
            text=self.tr(u'-     Полезные функции'),
            callback=self.run_tst_func,
            parent=self.iface.mainWindow(),
            checkable=False,
            add_to_toolbar=False)


        # вторая функция в выпадающем списке
        self.action2 = self.add_action(
            icon_path=None,
            text=self.tr(u'-     Экспорт в *.geojson отдельными файлами'),
            callback=self.run_GP,
            parent=self.iface.mainWindow(),
            checkable=False,
            add_to_toolbar=False)

        self.action3 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Создать временные слои'), \
                                       callback=self.run_create_tmp_lr, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action4 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Объединить слои'), \
                                       callback=self.run_mrg_lrs, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action5 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Исправить геометрию'), \
                                       callback=self.run_fix_geometry, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action6 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Экспорт в *.geojson crs APU'), \
                                       callback=self.run_export_to_geojson_apu, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action7 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Экспорт в *.geojson, crs 4326'), \
                                       callback=self.run_export_to_geojson_wgs, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action8 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Разница 2-х слоёв (GEOM & ATTR)'), \
                                       callback=self.run_compare_full, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action9 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Разница 2-х слоёв по GEOM'), \
                                       callback=self.run_compare_geom, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)

        self.action10 = self.add_action(icon_path=None, \
                                       text=self.tr(u'-     Экспорт в *.gpkg, crs APU'), \
                                       callback=self.run_export_to_gpkg, parent=self.iface.mainWindow(), \
                                       checkable=False, add_to_toolbar=False)


        # добавляем функции в меню
        self.popupMenu = QMenu(self.iface.mainWindow())

        # self.popupMenu.addAction(u'1 STEP:')
        self.popupMenu.addAction(u'HELPFULL FUNCTIONS:')
        self.popupMenu.addSeparator()
        self.popupMenu.addAction(self.action5)  # Исправить геометрию выделенных слоёв
        self.popupMenu.addAction(self.action3)  # Создать временные слои
        self.popupMenu.addAction(self.action4)  # Объединить выделенные слои
        self.popupMenu.addSeparator()
        self.popupMenu.addAction(self.action10)  # Экспорт в *.gpkg в crs APU
        self.popupMenu.addAction(self.action6)  # Экспорт в *.geojson в crs Default
        self.popupMenu.addAction(self.action7)  # Экспорт в *.geojson из APU в WGS84
        self.popupMenu.addSeparator()
        self.popupMenu.addAction(self.action8)  # Изменения данных GEOM + Attr (по совпавшим столбцам и без id, fid)
        self.popupMenu.addAction(self.action9)  # Изменения данных GEOM

        self.toolButton = QToolButton()

        iconpth = ":/plugins/"+f"{NAME_PLUG}"+'/logo_Fn.png'
        self.toolButton.setIcon(QIcon(iconpth))

        self.toolButton.setMenu(self.popupMenu)
        self.toolButton.setDefaultAction(self.action0)

        self.toolButton.setPopupMode(QToolButton.MenuButtonPopup)

        """ Поиск панели по текстовому заголовку mrgp_panels и добавляем popupMenu"""
        for x in self.iface.mainWindow().findChildren(QToolBar):
            # print(x.windowTitle())
            if x.windowTitle() == f"{NAME_PLUG}":
                x.addWidget(self.toolButton)

    """ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ЗАГЛУШИЛ КНОПКУ ПРИНЯТЫХ РЕШЕНИЙ   !!!!!!!!!!!!! """
    def add_popup_pr(self):
        pass

    def unload(self):
        """ЗАРЕЗЕВРИРОВАННАЯ Функция для правильной выгрузки plugin из Qgis"""
        for action in self.actions:
            self.iface.removePluginVectorMenu(self.tr(f"{NAME_PLUG}"), action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar
        del self.toolButton
        # self.iface.removeToolBarIcon(self.toolBtnAction)

    """ --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---  
                   ВЫЗОВ ПОЛЬЗОВАТЕЛЬСКИХ ФУНКЦИЙ ИЗ ДРУГОГО КЛАССА 
        --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---  """
    # region

    def show_cont_objects_in_layer(self):
        """ показывает кол-во объектов в слое """
        # allLayers = self.prj.instance().layerTreeRoot().findLayers()  # количество объектов в слое показываем
        allLayers = QgsProject.instance().layerTreeRoot().findLayers()  # количество объектов в слое показываем
        for (layer) in allLayers:
            if layer.name() == self.tmp_rslt.name():
                layer.setCustomProperty("showFeatureCount", True)

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА CREATE_TMP_LAYERS
    def run_create_tmp_lr(self):
        # try:
        #     self.add_to_db('CREATE_TMP_LAYERS')
        # except:
        #     print("Ошибка при вызове функции run_create_tmp_lr")

        # logging.info(f"STROKA 354 \nPATH:  \nLAYERS: {self.lrs}")

        print('run_CREATE_TMP_LAYERS')
        """ просто вызов функций из класса с функциями и передача параметров """
        self.lrs = self.iface.layerTreeView().selectedLayers()  # получили все выделенные слои
        # цикл по каждому выделенному слою
        for x in self.lrs:
            self.tmp_rslt = self.mrgp_func.create_tmp_lr(self, x)
            if self.tmp_rslt is None:
                continue
            self.tmp_rslt.setName(f'{self.tmp_rslt.name()}_tmp')  # переименовали слой
            self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
            self.show_cont_objects_in_layer()  # показали кол-во объектов в слое

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА FIX_GEOMETRY
    def run_fix_geometry(self):
        # try:
        #     self.add_to_db('FIX_GEOMETRY')
        # except:
        #     print("Ошибка при вызове функции run_fix_geometry")

        print('run_FIX_GEOMETRY')
        """ просто вызов функций из класса с функциями и передача параметров """
        self.lrs = self.iface.layerTreeView().selectedLayers()  # получили все выделенные слои
        # цикл по каждому выделенному слою
        for x in self.lrs:
            self.tmp_rslt = self.mrgp_func.fix_geometry(self, x)
            self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
            self.show_cont_objects_in_layer()  # показали кол-во объектов в слое

    # endregion

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА MERGE_LAYERS
    def run_mrg_lrs(self):
        # try:
        #     self.add_to_db('MERGE_LAYERS')
        # except:
        #     print("Ошибка при вызове функции run_mrg_lrs")

        print('run_MERGE_LAYERS')
        """ просто вызов функций из класса с функциями и передача параметров """
        self.lrs = self.iface.layerTreeView().selectedLayers()  # получили все выделенные слои
        self.mrgp_func.mrg_lrs(self)
        self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
        self.show_cont_objects_in_layer()  # показали кол-во объектов в слое

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА GP
    def run_GP(self):
        # try:
        #     self.add_to_db('GP_button')
        # except:
        #     print("Ошибка при вызове функции run_compare_geom")

        self.dlg_GP.show()  # запуск дочернего окна
        self.dlg_GP.exec_()  #

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА GEO_GEOCOMPARE
    def run_compare_geom(self):
        # try:
        #     self.add_to_db('GEO_GEOCOMPARE')
        # except:
        #     print("Ошибка при вызове функции run_compare_geom")

        print('run_GEO_GEOCOMPARE')
        """ сравниваем только геометрию """
        # проверяем чтоб выбранных слоёв было ровно два
        self.tmp_rslt = self.iface.layerTreeView().selectedLayers()
        if len(self.tmp_rslt) != 2:
            self.iface.messageBar().pushMessage("Oooops", "Выдели РОВНО ДВА слоя!", level=Qgis.Critical, duration=3)
            return

        self.mrgp_func.geom_cmpr_lrs(self)  # сравниваем слои

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА GEO_GEOCOMPARE_AND_ATTRIBUTES
    def run_compare_full(self):
        # try:
        #     self.add_to_db('GEOCOMPARE_AND_ATTRIBUTES')
        # except:
        #     print("Ошибка при вызове функции run_compare_full")

        print('run_GEO_GEOCOMPARE_AND_ATTRIBUTES')
        """ основная функция для сравнения слоёв """
        # проверяем чтоб выбранных слоёв было ровно два
        self.tmp_rslt = self.iface.layerTreeView().selectedLayers()
        if len(self.tmp_rslt) != 2:
            self.iface.messageBar().pushMessage("Oooops", "Выдели РОВНО ДВА слоя!", level=Qgis.Critical, duration=3)
            return

        self.mrgp_func.cmpr_lrs(self)  # сравниваем слои

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА TO_GEOJSON_CRS_APU
    def run_export_to_geojson_apu(self):
        # try:
        #     self.add_to_db('ExportToGeojson_CRS_APU')
        # except:
        #     print("Ошибка при вызове функции run_export_to_geojson_apu")


        print('run_EXPORT_TO_GEOJSON_CRS_APU')
        """ export layrs to geojson with crs MSK"""
        fl_nm = QFileDialog().getExistingDirectory()  # получаем от user путь к папке
        print(f'{fl_nm})')
        """ просто вызов функций из класса с функциями и передача параметров """
        self.lrs = self.iface.layerTreeView().selectedLayers()  # получили все выделенные слои
        # цикл по каждому выделенному слою
        for lr in self.lrs:
            self.mrgp_func.save_lr_to_geojson(self, lr, fl_nm)

        self.iface.messageBar().pushInfo('MSG', f'DONE')

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА TO_GEOJSON_CRS_WGS84
    def run_export_to_geojson_wgs(self):
        # try:
        #     self.add_to_db('ExportToGeojson_CRS_WGS84')
        # except:
        #     print("Ошибка при вызове функции run_export_to_geojson_wgs")

        # print('run_EXPORT_TO_GEOJSON_CRS_WGS84')
        """ export layrs to geojson with crs MSK"""
        fl_nm = QFileDialog().getExistingDirectory()  # получаем от user путь к папке
        self.dir_path = fl_nm

        work_dir = pathlib.Path(fl_nm)
        if not work_dir.is_dir() or fl_nm == '':
            self.iface.messageBar().pushMessage("Warning",
                                           "Путь к директории сохранения не действителен!",
                                           level=Qgis.Warning,
                                           duration=5)
            # self.iface.messageBar().pushInfo('MSG', f'Путь к директории сохранения не действителен!')
            print("Путь к директории сохранения не действителен!")
            return False


        """ просто вызов функций из класса с функциями и передача параметров """
        self.lrs = self.iface.layerTreeView().selectedLayers()  # получили все выделенные слои
        # цикл по каждому выделенному слою
        for lr in self.lrs:
            self.mrgp_func.save_lr_to_geojson_wgs(self, lr, fl_nm)

        # self.iface.messageBar().pushInfo('MSG', f'DONE')
        self.displaye_custom_message_bar(title='MSG', message=f'Результаты сохранены - {fl_nm}')

    def open_folder_in_explorer(self):
        try:
            path = self.dir_path
            path = os.path.realpath(path)
            os.startfile(path)
        except:
            print(f"error in function open_folder_in_explorer")

    def displaye_custom_message_bar(self, title, message):
        widget = self.iface.messageBar().createMessage(title, message)
        button = QPushButton(widget)
        button.setText("ОТКРЫТЬ КАТАЛОГ В ПРОВОДНИКЕ")
        button.pressed.connect(self.open_folder_in_explorer)
        widget.layout().addWidget(button)
        # self.iface.messageBar().pushWidget(widget, Qgis.Info, duration=15)
        self.iface.messageBar().pushWidget(widget, Qgis.Info)


    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ФУНКЦИЯ записи в бд
    def add_to_db(self, any_txt):
        """ Подключаемся к Базе """
        try:
            self.conn = psycopg2.connect(
                f"dbname = {DB_MRGP} host = {DB_IP_MRGP} port = {Port_MRGP} user = {USER_NAME} password = {PASS_USER}")
            self.cur = self.conn.cursor()
        except:
            print(f'Не подключились к БД {DB_IP_MRGP}  {DB_MRGP}')

        """   GEOM   """
        f = QgsFeature()
        # f.setGeometry(QgsGeometry.fromRect(qgis.utils.iface.mapCanvas().extent()))
        f.setGeometry(QgsGeometry.fromRect(self.iface.mapCanvas().extent()))
        geomet = (f.geometry().asWkt()).replace('Polygon (', ' MultiPolygon ((') + ')'
        # print(f"GEOMET:{geomet}")

        """ QGIS_INFO  """
        version = QgsExpressionContextUtils.globalScope().variable('qgis_version')
        user_acc_name = QgsExpressionContextUtils.globalScope().variable('user_account_name')
        user_full_name = QgsExpressionContextUtils.globalScope().variable('user_full_name')
        qgis_os_name = QgsExpressionContextUtils.globalScope().variable('qgis_os_name')

        # """  CURR TIME  """
        # tm = time.strftime("%d-%m-%Y %H:%M:%S")

        """  NETWORK INFO  """
        hostname = socket.gethostname()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        IPAddr = s.getsockname()[0]

        scr_sql = f"""INSERT INTO program_user.info_fn_call_stats(
                            "geom",
                            "qgis_version",
                            "user_account_name",
                            "user_full_name",
                            "qgis_os_name",
                            "call_fn",
                            "host_name",
                            "host_ip"
                            )
                        VALUES (
                            ST_GeomFromText('{geomet}'),    --geom
                            '{version}',                    --qgis_version
                            '{user_acc_name}',              --task_2
                            '{user_full_name}',             --user_full_name
                            '{qgis_os_name}',               --qgis_os_name
                            '{any_txt}',                    --call_fn
                            '{hostname}',                   --host_name
                            '{IPAddr}'                      --host_ip
                            );"""

        self.cur.execute(f"{scr_sql}")

        self.conn.commit()
        self.cur.close()
        self.conn.close()

        # print(f'{geomet} \n  Вызов из {any_txt}')

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА Fn_BUTON_FULL
    def run_tst_func(self):
        self.test_print()
        # try:
        #     self.add_to_db('FN_button')
        # except:
        #     print("Ошибка при вызове функции run_json")
        pass

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА LD_START
    def run(self, startX, startY, endX, endY):
        # условие - если рамка не определена то выход из функции
        if startX == endX and startY == endY:
            return

        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА LD_START
        # try:
        #     self.add_to_db('LD_button')
        # except:
        #     print("Ошибка при вызове функции run")


        # инициализация класса и передача параметров для конструктора
        self.dlg = GPKG_creatorDialog(self.iface, startX, startY, endX, endY)
        self.dlg.show()  # запуск дочернего окна
        result = self.dlg.exec_()  # получение результата выполнения
        if result:
            pass

    def runRectangle(self, b):

        if b:
            self.iface.mapCanvas().setMapTool(self.rectangleAreaTool)
        else:
            self.iface.mapCanvas().unsetMapTool(self.rectangleAreaTool)

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   ТОЧКА ВХОДА TO_GPKG
    def run_export_to_gpkg(self):
        # try:
        #     self.add_to_db('ExportToGPKG_CRS_APU')
        # except:
        #     print("Ошибка при вызове функции run_export_to_gpkg")

        """ export layrs to gpkg with crs APU"""
        fl_nm = QFileDialog().getExistingDirectory()  # получаем от user путь к папке

        now_name = datetime.datetime.now().strftime("%Y%m%d%H%M")

        pth = (f'{fl_nm}'+f'/{now_name}.gpkg')
        print(f'{pth}')
        """ просто вызов функций из класса с функциями и передача параметров """
        self.lrs = self.iface.layerTreeView().selectedLayers()  # получили все выделенные слои

        # цикл по каждому выделенному слою
        rslt_lrs = []
        for x in self.lrs:
            self.tmp_rslt = self.mrgp_func.create_tmp_lr(self, x)
            if self.tmp_rslt is None:
                continue
            # self.tmp_rslt.setName(f'{self.tmp_rslt.name()}_tmp')  # переименовали слой
            rslt_lrs.append(self.tmp_rslt)
            # self.prj.instance().addMapLayer(self.tmp_rslt)  # добавили слой на карту
            # self.show_cont_objects_in_layer()  # показали кол-во объектов в слое

        # устанавливаем систему координат APU
        crs_apu = QgsCoordinateReferenceSystem()
        crs_apu.createFromProj4(APU_SRC)
        for tmp_lr in rslt_lrs:
            tmp_lr.setCrs(crs_apu)

        # logging.info(f"STROKA 548 \nPATH: {pth}  \nLAYERS: {self.lrs}")
        GPKG_creatorDialog.pack_lrs(self, pth, rslt_lrs)

        self.iface.messageBar().pushInfo('MSG', f'DONE')


    def test_print(self=None, a="A"):
        print(f'Тестовый принт {a}')


    def getwkt(self):
        mc = self.iface.mapCanvas()
        layer = mc.currentLayer()
        feat = layer.selectedFeatures()
        lst_geom = []
        for f in feat:
            lst_geom.append((f.geometry()).asWkt())
        # # geom = feat[0].geometry()
        # # wkt_geom = geom.asWkt()
        # print(f'{lst_geom}')

        clipboard = QApplication.clipboard()
        # clipboard.setText(wkt_geom)
        clipboard.setText('\n'.join(lst_geom))
        self.iface.messageBar().pushMessage("Get WKT", "WKT copied to clipboard", level=Qgis.Info, duration=5)

class mrgp_func(mrgp_panels):
    def __init__(self, iface):
        super().__init__(iface)

    def geom_cmpr_lrs(self):
        """  функция сравнения слоёв terr """
        self.iface.messageBar().pushMessage('Сравниваем : ', f'ТОЛЬКО ГЕОМЕТРИЮ', level=Qgis.Success, duration=5)

        algorithmOutput = processing.run(
            "native:detectvectorchanges",
            {
                "ORIGINAL": self.tmp_rslt[0],
                'REVISED': self.tmp_rslt[1],
                'COMPARE_ATTRIBUTES': [],
                'MATCH_TYPE': 1,
                'UNCHANGED': f"memory:UNCHANGED",
                "ADDED": f"memory:Ad_{self.tmp_rslt[0].name()}",
                "DELETED": f"memory:Dl_{self.tmp_rslt[0].name()}"
            },
            context=self.cont_ext,
            feedback=self.feed_back
        )

        # self.prj.instance().addMapLayer(algorithmOutput["UNCHANGED"])  # добавили слой на карту
        self.prj.instance().addMapLayer(algorithmOutput["ADDED"])  # добавили слой на карту
        self.prj.instance().addMapLayer(algorithmOutput["DELETED"])  # добавили слой на карту

        # lst_nms = ['UNCHANGED', f'ADD_TO_{self.tmp_rslt[0].name()}', f'DEL_FROM_{self.tmp_rslt[0].name()}']
        lst_nms = [f'Ad_{self.tmp_rslt[0].name()}', f'Dl_{self.tmp_rslt[0].name()}']
        allLayers = QgsProject.instance().layerTreeRoot().findLayers()  # количество объектов в слое показываем
        for (layer) in allLayers:
            if layer.name() in lst_nms:
                layer.setCustomProperty("showFeatureCount", True)

    def get_dict_fields(self, lr):
        """ получаем словарь где ключ - это индекс полей, значение - это имя колонки аттрибутов слоя """
        # lr = iface.activeLayer()
        fields = lr.dataProvider().fields()
        # ind_nms = [f.indexFromName(f.name()) for f in fields]
        ind_nms_dict = {fields.indexFromName(f.name()): f.name() for f in fields}
        return ind_nms_dict

    def cmpr_lrs(self):
        """  функция сравнения слоёв terr """

        a = self.mrgp_func.get_dict_fields(self, self.tmp_rslt[0])  # получили словарь колонок и индексов первой таблицы
        b = self.mrgp_func.get_dict_fields(self, self.tmp_rslt[1])  # получили словарь колонок и индексов второй таблицы

        c = list(set(a.values()) & set(b.values()))  # нашли пересечение двух списков
        cmpr_field = [f for f in c if f not in ['fid', 'id']]  # удалили из списка поле fid

        self.iface.messageBar().pushMessage('Сравнили по полям: ', f'{cmpr_field}', level=Qgis.Success, duration=5)
        print(f"{cmpr_field}")

        algorithmOutput = processing.run(
            "native:detectvectorchanges",
            {
                "ORIGINAL": self.tmp_rslt[0],
                'REVISED': self.tmp_rslt[1],
                'COMPARE_ATTRIBUTES': cmpr_field,
                'MATCH_TYPE': 1,
                'UNCHANGED': f"memory:UNCHANGED",
                "ADDED": f"memory:Add_{self.tmp_rslt[0].name()}",
                "DELETED": f"memory:Del_{self.tmp_rslt[0].name()}"
            },
            context=self.cont_ext,
            feedback=self.feed_back
        )

        # self.prj.instance().addMapLayer(algorithmOutput["UNCHANGED"])  # добавили слой на карту
        self.prj.instance().addMapLayer(algorithmOutput["ADDED"])  # добавили слой на карту
        self.prj.instance().addMapLayer(algorithmOutput["DELETED"])  # добавили слой на карту

        # lst_nms = ['UNCHANGED', f'ADD_TO_{self.tmp_rslt[0].name()}', f'DEL_FROM_{self.tmp_rslt[0].name()}']
        lst_nms = [f'Add_{self.tmp_rslt[0].name()}', f'Del_{self.tmp_rslt[0].name()}']
        allLayers = QgsProject.instance().layerTreeRoot().findLayers()  # количество объектов в слое показываем
        for (layer) in allLayers:
            if layer.name() in lst_nms:
                layer.setCustomProperty("showFeatureCount", True)

    def save_lr_to_geojson(self, lr, pth):
        """ сохраняем слой в geojson формате, дублирование имен слоёв недопустимо """

        processing.run(
            "native:savefeatures",
            {
                'INPUT': lr,
                'OUTPUT': f'{pth}/{lr.name()}.geojson',
                'LAYER_NAME': '',
                'DATASOURCE_OPTIONS': '',
                'LAYER_OPTIONS': ''
            })

    def save_lr_to_geojson_wgs(self, lr, pth):
        """ перепроецируем и сохраняем слой в geojson формате дублирование имён недопустимо """

        processing.run(
            "native:reprojectlayer",
            {
                'INPUT': lr,
                'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:4326'),
                'OPERATION': '+proj=pipeline +step +inv +proj=tmerc +lat_0=55.66666666667 +lon_0=37.5 +k=1 '
                             '+x_0=12 +y_0=14 +ellps=bessel +step +proj=push +v_3 +step +proj=cart +ellps=bessel '
                             '+step +proj=helmert +x=316.151 +y=78.924 +z=589.65 +rx=-1.57273 +ry=2.69209 '
                             '+rz=2.34693 +s=8.4507 +convention=position_vector +step +inv +proj=cart '
                             '+ellps=WGS84 +step +proj=pop +v_3 +step +proj=unitconvert +xy_in=rad +xy_out=deg',

                'OUTPUT': f'{pth}/{lr.name()}.geojson'
            },
            context=self.cont_ext,
            feedback=self.feed_back
        )

    def mrg_lrs(self, name='объединенные_слои'):
        """ объединяем выбранные слои """
        algorithmOutput = processing.run(
            "native:mergevectorlayers",
            {
                'CRS': QgsCoordinateReferenceSystem(f'{APU_SRC}'),
                'LAYERS': self.lrs,
                'OUTPUT': f'memory:{name}_MRG'
            },
            context=self.cont_ext,
            feedback=self.feed_back
        )

        self.tmp_rslt = algorithmOutput["OUTPUT"]

    def fix_geometry(self, lr):
        """ Исправление геометрии """
        fix_layer = processing.run(
            "native:fixgeometries",
            {
                'INPUT': lr,
                'OUTPUT': f'memory:{lr.name()}_FIX'
            })

        return fix_layer["OUTPUT"]

    def create_tmp_lr(self, lr):
        """ создаём временный слой """
        return lr.materialize(QgsFeatureRequest().setFilterFids(lr.allFeatureIds()))

