# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MRGP - to gpkg
 ***************************************************************************/
"""
from __future__ import absolute_import

from builtins import str
import os
import datetime

from PyQt5.QtXml import QDomDocument
from qgis import processing
from processing import Processing as pr

from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QMessageBox, QProgressBar
from qgis.PyQt import uic
from qgis.PyQt.QtCore import pyqtSlot, QThreadPool, Qt
from qgis.core import Qgis, QgsGeometry, QgsProject, QgsVectorLayer, QgsApplication, QgsCoordinateReferenceSystem, \
    QgsProcessingFeedback, QgsProcessingContext
from qgis.core.additions import processing

from . import mrgp_panels

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'mrgp.ui'))
APU_SRC = r"+proj=tmerc +lat_0=55.66666666667 +lon_0=37.5 +k=1 +x_0=12 +y_0=14 +ellps=bessel " \
          r"+towgs84=316.151,78.924,589.65,-1.57273,2.69209,2.34693,8.4507 +units=m +no_defs "

# import logging
# # PLUG_PATH = os.path.dirname(__file__)
# # cur_path = os.path.join(PLUG_PATH, r"DELETE")
# # abs_path = os.path.abspath(cur_path)
# # logging.basicConfig(filename=f'{cur_path}/LOG_20230425.txt', filemode="w", level=logging.INFO)


class GPKG_creatorDialog(QDialog, FORM_CLASS):
    def __init__(self, iface, startX, startY, endX, endY, parent=None):
        """Constructor."""
        super(GPKG_creatorDialog, self).__init__(parent)

        self.setupUi(self)

        self.iface = iface

        self.setCoordinates(startX, startY, endX, endY)

        self.threadpool = QThreadPool()

        self.size = 0

        self.plugin_dir = os.path.dirname(__file__)

        self.mrgp_panels = None

    def setCoordinates(self, startX, startY, endX, endY):
        if startX < endX:
            minLong = startX
            maxLong = endX
        else:
            minLong = endX
            maxLong = startX

        if startY < endY:
            minLat = startY
            maxLat = endY
        else:
            minLat = endY
            maxLat = startY

        self.wEdit.setText(str(minLong))
        self.sEdit.setText(str(minLat))
        self.eEdit.setText(str(maxLong))
        self.nEdit.setText(str(maxLat))

    def reorganiz_columns(self, lr, lr_name, scr):
        """ реорганизация колонок """
        alg_name = "native:refactorfields"
        params = \
            {
                "INPUT": lr,
                'FIELDS_MAPPING': scr,
                "OUTPUT": f"memory:{lr_name}"
            }

        alg = QgsApplication.processingRegistry().algorithmById(alg_name)
        # layer = processing.run(alg, params)['OUTPUT']
        var = pr.runAlgorithm(alg, params)['OUTPUT']
        return var

    def fix_table(self, lr):
        """ исправление геометрии """
        alg_name = "native:fixgeometries"
        params = \
            {
                "INPUT": lr,
                "OUTPUT": f"memory:{lr.name()}"
            }

        alg = QgsApplication.processingRegistry().algorithmById(alg_name)
        # layer = processing.run(alg, params)['OUTPUT']
        var = pr.runAlgorithm(alg, params)['OUTPUT']
        return var

    def select_by_geom_and_merge(self, geom, name_new_lr, lrs_list, scr):
        # делаем выборку в каждом слое
        try:
            for lr in lrs_list:
                to_lr = QgsProject.instance().mapLayersByName(lr)[0]
                ftrs = to_lr.getFeatures()
                to_lr.removeSelection()
                for feature in ftrs:
                    if geom.intersects(feature.geometry()):
                        to_lr.select(feature.id())
        except:
            # logging.info(f"STROKA 110 \nNAME_LR: {name_new_lr}  \nLIST_LRS{lrs_list}")
            return

        # создаем временный слой и сохраняем в него выбранные объекты из списка слоёв
        tmp_lr = QgsVectorLayer('MultiPolygon', name_new_lr, 'memory')
        tmp_lr.startEditing()  # открываем на редактирование
        dp = tmp_lr.dataProvider()

        try:
            for lr in lrs_list:
                to_lr = QgsProject.instance().mapLayersByName(lr)[0]
                feat = to_lr.selectedFeatures()
                fields = to_lr.fields()

                dp.addAttributes(fields)
                dp.addFeatures(feat)

                tmp_lr.updateFields()
                tmp_lr.commitChanges()  # сохраняем изменения в слое
        except:
            # logging.info(f"STROKA 130 \nNAME_LR: {lr}  \nLIST_LRS{lrs_list}")
            return

        # выполняем реорганизацию таблиц
        tmp_lr = self.reorganiz_columns(tmp_lr, name_new_lr, scr)

        # исправляем геометрию
        # print(f"fix lr {tmp_lr.name()}")
        tmp_lr = self.fix_table(tmp_lr)

        myDocument = QDomDocument('qgis')  # подготавливаем документ со стилями
        to_lr = QgsProject.instance().mapLayersByName(lrs_list[0])[0]  # получаем слой
        to_lr.exportNamedStyle(myDocument)  # получаес стили в документ
        success, message = tmp_lr.importNamedStyle(myDocument)  # назначаем стили слою

        return tmp_lr

    def pack_lrs(self, path_out, LAYERS):
        '''упаковываем выбранные слои в gpkg и сохраняем по пути'''
        # LAYERS = self.sel_lrs
        LRS = [x for x in LAYERS if x is not None]
        alg_name = "native:package"
        params = \
            {
                'LAYERS': LRS,
                'OUTPUT': path_out,
                'OVERWRITE': True,
                'SAVE_STYLES': True,
                'SAVE_METADATA': True,
                'SELECTED_FEATURES_ONLY': False
            }
        alg = QgsApplication.processingRegistry().algorithmById(alg_name)
        # layer = processing.run(alg, params)['OUTPUT']
        var = pr.runAlgorithm(alg, params)['OUTPUT']
        # logging.info(f"STROKA 158 \nPATH: {path_out}  \nLAYERS: {LRS}")


    @pyqtSlot()
    def on_saveButton_clicked(self):
        ret = QFileDialog.getSaveFileName(parent=None, caption='Define file name and location',
                                          filter='GPKG Files(*.gpkg)')
        fileName = ret[0]

        split = fileName.split('.')
        if len(split) > 0 and split[-1] == 'gpkg':
            pass
        else:
            fileName += '.gpkg'

        self.filenameEdit.setText(fileName)

    @pyqtSlot()
    def on_button_box_accepted(self):
        if self.filenameEdit.text() == '':
            QMessageBox.warning(self, self.tr("Warning!"), self.tr("Please, select a location to save the file."))
            return

        # Формируем строку для WKT
        str_wkt_geom = f'MultiPolygon((({self.wEdit.text()} {self.nEdit.text()}, {self.wEdit.text()} {self.sEdit.text()}, {self.eEdit.text()} {self.sEdit.text()}, {self.eEdit.text()} {self.nEdit.text()}, {self.wEdit.text()} {self.nEdit.text()}))) '
        g = QgsGeometry.fromWkt(str_wkt_geom)  # рамка (полигон) с которой пересечение

        """ START script for reoarganiz """
        scr_bld = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                    'type_name': 'int8'
                    }, {'expression': '"NAME_OBJ"', 'length': 8, 'name': 'NAME_OBJ', 'precision': 0, 'sub_type': 0,
                        'type': 10, 'type_name': 'text'
                        }, {'expression': '"ID"', 'length': 0, 'name': 'ID', 'precision': 0, 'sub_type': 0, 'type': 6,
                            'type_name': 'double precision'
                            },
                   {'expression': '"ID_PARENT"', 'length': 2, 'name': 'ID_PARENT', 'precision': 0, 'sub_type': 0,
                    'type': 10, 'type_name': 'text'
                    }, {'expression': '"VID_ZD"', 'length': 254, 'name': 'VID_ZD', 'precision': 0, 'sub_type': 0,
                        'type': 10, 'type_name': 'text'
                        }, {'expression': '"TYPE_ZD"', 'length': 2, 'name': 'TYPE_ZD', 'precision': 0, 'sub_type': 0,
                            'type': 10, 'type_name': 'text'
                            },
                   {'expression': '"STATE"', 'length': 254, 'name': 'STATE', 'precision': 0, 'sub_type': 0, 'type': 10,
                    'type_name': 'text'
                    }, {'expression': '"NAME_BUI"', 'length': 254, 'name': 'NAME_BUI', 'precision': 0, 'sub_type': 0,
                        'type': 10, 'type_name': 'text'
                        },
                   {'expression': '"GLOBAL_ID"', 'length': 0, 'name': 'GLOBAL_ID', 'precision': 0, 'sub_type': 0,
                    'type': 6, 'type_name': 'double precision'
                    }, {'expression': '"SXF"', 'length': 254, 'name': 'SXF', 'precision': 0, 'sub_type': 0, 'type': 10,
                        'type_name': 'text'
                        }, {'expression': '"t_from_contents"', 'length': 254, 'name': 't_from_contents', 'precision': 0,
                            'sub_type': 0, 'type': 10, 'type_name': 'text'
                            }]

        scr_bld_pr = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                       'type_name': 'int8'
                       }, {'expression': '"id"', 'length': 0, 'name': 'id', 'precision': 0, 'sub_type': 0, 'type': 6,
                           'type_name': 'double precision'
                           }, {'expression': '"tip_obj"', 'length': 254, 'name': 'tip_obj', 'precision': 0, 'sub_type': 0,
                               'type': 10, 'type_name': 'text'
                               },
                      {'expression': '"name_obj"', 'length': 254, 'name': 'name_obj', 'precision': 0, 'sub_type': 0,
                       'type': 10, 'type_name': 'text'
                       }, {'expression': '"et_naz"', 'length': 0, 'name': 'et_naz', 'precision': 0, 'sub_type': 0,
                           'type': 2, 'type_name': 'integer'
                           }, {'expression': '"tip_obj_eng"', 'length': 254, 'name': 'tip_obj_eng', 'precision': 0,
                               'sub_type': 0, 'type': 10, 'type_name': 'text'
                               },
                      {'expression': '"h_m"', 'length': 0, 'name': 'h_m', 'precision': 0, 'sub_type': 0, 'type': 6,
                       'type_name': 'double precision'
                       }, {'expression': '"t_from_contents"', 'length': 50, 'name': 't_from_contents', 'precision': 0,
                           'sub_type': 0, 'type': 10, 'type_name': 'text'
                           },
                      {'expression': '"prim"', 'length': 254, 'name': 'prim', 'precision': 0, 'sub_type': 0, 'type': 10,
                       'type_name': 'text'
                       },
                      {'expression': '"hz_m"', 'length': 0, 'name': 'hz_m', 'precision': 0, 'sub_type': 0, 'type': 6,
                       'type_name': 'double precision'
                       }]

        scr_bld_ex = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                       'type_name': 'int8'
                       }, {'expression': '"id"', 'length': 0, 'name': 'id', 'precision': 0, 'sub_type': 0, 'type': 6,
                           'type_name': 'double precision'
                           }, {'expression': '"tip_obj"', 'length': 254, 'name': 'tip_obj', 'precision': 0, 'sub_type': 0,
                               'type': 10, 'type_name': 'text'
                               },
                      {'expression': '"name_obj"', 'length': 254, 'name': 'name_obj', 'precision': 0, 'sub_type': 0,
                       'type': 10, 'type_name': 'text'
                       }, {'expression': '"et_naz"', 'length': 0, 'name': 'et_naz', 'precision': 0, 'sub_type': 0,
                           'type': 2, 'type_name': 'integer'
                           }, {'expression': '"tip_obj_eng"', 'length': 254, 'name': 'tip_obj_eng', 'precision': 0,
                               'sub_type': 0, 'type': 10, 'type_name': 'text'
                               },
                      {'expression': '"h_m"', 'length': 0, 'name': 'h_m', 'precision': 0, 'sub_type': 0, 'type': 6,
                       'type_name': 'double precision'
                       }, {'expression': '"t_from_contents"', 'length': 50, 'name': 't_from_contents', 'precision': 0,
                           'sub_type': 0, 'type': 10, 'type_name': 'text'
                           },
                      {'expression': '"prim"', 'length': 254, 'name': 'prim', 'precision': 0, 'sub_type': 0, 'type': 10,
                       'type_name': 'text'
                       },
                      {'expression': '"hz_m"', 'length': 0, 'name': 'hz_m', 'precision': 0, 'sub_type': 0, 'type': 6,
                       'type_name': 'double precision'
                       }]

        scr_land_ex = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                        'type_name': 'int8'
                        }, {'expression': '"id"', 'length': 0, 'name': 'id', 'precision': 0, 'sub_type': 0, 'type': 6,
                            'type_name': 'double precision'
                            },
                       {'expression': '"sqrt"', 'length': 0, 'name': 'sqrt', 'precision': 0, 'sub_type': 0, 'type': 6,
                        'type_name': 'double precision'
                        }, {'expression': '"vid_planir_element"', 'length': 254, 'name': 'vid_planir_element',
                            'precision': 0, 'sub_type': 0, 'type': 10, 'type_name': 'text'
                            },
                       {'expression': '"prim_txt"', 'length': 254, 'name': 'prim_txt', 'precision': 0, 'sub_type': 0,
                        'type': 10, 'type_name': 'text'
                        }, {'expression': '"tip_obj_eng"', 'length': 254, 'name': 'tip_obj_eng', 'precision': 0,
                            'sub_type': 0, 'type': 10, 'type_name': 'text'
                            },
                       {'expression': '"h_m"', 'length': 0, 'name': 'h_m', 'precision': 0, 'sub_type': 0, 'type': 6,
                        'type_name': 'double precision'
                        }, {'expression': '"t_from_contents"', 'length': 50, 'name': 't_from_contents', 'precision': 0,
                            'sub_type': 0, 'type': 10, 'type_name': 'text'}]

        scr_land_pr = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                        'type_name': 'int8'
                        }, {'expression': '"id"', 'length': 0, 'name': 'id', 'precision': 0, 'sub_type': 0, 'type': 6,
                            'type_name': 'double precision'
                            },
                       {'expression': '"sqrt"', 'length': 0, 'name': 'sqrt', 'precision': 0, 'sub_type': 0, 'type': 6,
                        'type_name': 'double precision'
                        }, {'expression': '"vid_planir_element"', 'length': 254, 'name': 'vid_planir_element',
                            'precision': 0, 'sub_type': 0, 'type': 10, 'type_name': 'text'
                            },
                       {'expression': '"prim_txt"', 'length': 254, 'name': 'prim_txt', 'precision': 0, 'sub_type': 0,
                        'type': 10, 'type_name': 'text'
                        }, {'expression': '"tip_obj_eng"', 'length': 254, 'name': 'tip_obj_eng', 'precision': 0,
                            'sub_type': 0, 'type': 10, 'type_name': 'text'
                            },
                       {'expression': '"h_m"', 'length': 0, 'name': 'h_m', 'precision': 0, 'sub_type': 0, 'type': 6,
                        'type_name': 'double precision'
                        }, {'expression': '"t_from_contents"', 'length': 50, 'name': 't_from_contents', 'precision': 0,
                            'sub_type': 0, 'type': 10, 'type_name': 'text'
                            }]

        scr_ld_terr = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                        'type_name': 'int8'
                        }, {'expression': '"ADDRESS"', 'length': 254, 'name': 'ADDRESS', 'precision': 0, 'sub_type': 0,
                            'type': 10, 'type_name': 'text'
                            }, {'expression': '"ISPOLNITEL"', 'length': 254, 'name': 'ISPOLNITEL', 'precision': 0,
                                'sub_type': 0, 'type': 10, 'type_name': 'text'
                                },
                       {'expression': '"DATE"', 'length': 0, 'name': 'DATE', 'precision': 0, 'sub_type': 0, 'type': 14,
                        'type_name': 'date'
                        }, {'expression': '"DATE_LAST_CHANGE"', 'length': 0, 'name': 'DATE_LAST_CHANGE', 'precision': 0,
                            'sub_type': 0, 'type': 14, 'type_name': 'date'
                            },
                       {'expression': '"t_from_contents"', 'length': 20, 'name': 't_from_contents', 'precision': 0,
                        'sub_type': 0, 'type': 10, 'type_name': 'text'
                        }]

        scr_road = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                     'type_name': 'int8'
                     }, {'expression': '"NAME_OBJ"', 'length': 4, 'name': 'NAME_OBJ', 'precision': 0, 'sub_type': 0,
                         'type': 10, 'type_name': 'text'
                         }, {'expression': '"ID"', 'length': 0, 'name': 'ID', 'precision': 0, 'sub_type': 0, 'type': 6,
                             'type_name': 'double precision'
                             },
                    {'expression': '"ID_PARENT"', 'length': 2, 'name': 'ID_PARENT', 'precision': 0, 'sub_type': 0,
                     'type': 10, 'type_name': 'text'
                     }, {'expression': '"VID_STR"', 'length': 2, 'name': 'VID_STR', 'precision': 0, 'sub_type': 0,
                         'type': 10, 'type_name': 'text'
                         }, {'expression': '"STR_STD"', 'length': 0, 'name': 'STR_STD', 'precision': 0, 'sub_type': 0,
                             'type': 6, 'type_name': 'double precision'
                             },
                    {'expression': '"CLADR"', 'length': 0, 'name': 'CLADR', 'precision': 0, 'sub_type': 0, 'type': 6,
                     'type_name': 'double precision'
                     }, {'expression': '"ASUR"', 'length': 0, 'name': 'ASUR', 'precision': 0, 'sub_type': 0, 'type': 6,
                         'type_name': 'double precision'
                         },
                    {'expression': '"NAME_STR"', 'length': 254, 'name': 'NAME_STR', 'precision': 0, 'sub_type': 0,
                     'type': 10, 'type_name': 'text'
                     }, {'expression': '"VID_ROAD"', 'length': 254, 'name': 'VID_ROAD', 'precision': 0, 'sub_type': 0,
                         'type': 10, 'type_name': 'text'
                         },
                    {'expression': '"EXT_NAME"', 'length': 254, 'name': 'EXT_NAME', 'precision': 0, 'sub_type': 0,
                     'type': 10, 'type_name': 'text'
                     }, {'expression': '"GLOBAL_ID"', 'length': 0, 'name': 'GLOBAL_ID', 'precision': 0, 'sub_type': 0,
                         'type': 6, 'type_name': 'double precision'
                         },
                    {'expression': '"SXF"', 'length': 254, 'name': 'SXF', 'precision': 0, 'sub_type': 0, 'type': 10,
                     'type_name': 'text'
                     }, {'expression': '"t_from_contents"', 'length': 254, 'name': 't_from_contents', 'precision': 0,
                         'sub_type': 0, 'type': 10, 'type_name': 'text'
                         }]

        scr_terr_razv = [{'expression': '"fid"', 'length': 0, 'name': 'fid', 'precision': 0, 'sub_type': 0, 'type': 4,
                          'type_name': 'int8'
                          }, {'expression': '"id"', 'length': 0, 'name': 'id', 'precision': 0, 'sub_type': 0, 'type': 2,
                              'type_name': 'integer'
                              }, {'expression': '"Наименование"', 'length': 254, 'name': 'Наименование', 'precision': 0,
                                  'sub_type': 0, 'type': 10, 'type_name': 'text'
                                  },
                         {'expression': '"Адрес"', 'length': 254, 'name': 'Адрес', 'precision': 0, 'sub_type': 0,
                          'type': 10, 'type_name': 'text'
                          }, {'expression': '"Застройщик"', 'length': 254, 'name': 'Застройщик', 'precision': 0,
                              'sub_type': 0, 'type': 10, 'type_name': 'text'
                              },
                         {'expression': '"Статус"', 'length': 254, 'name': 'Статус', 'precision': 0, 'sub_type': 0,
                          'type': 10, 'type_name': 'text'
                          },
                         {'expression': '"Документ"', 'length': 254, 'name': 'Документ', 'precision': 0, 'sub_type': 0,
                          'type': 10, 'type_name': 'text'
                          },
                         {'expression': '"СПП_всего"', 'length': 0, 'name': 'СПП_всего', 'precision': 0, 'sub_type': 0,
                          'type': 6, 'type_name': 'double precision'
                          },
                         {'expression': '"СПП_жилая"', 'length': 0, 'name': 'СПП_жилая', 'precision': 0, 'sub_type': 0,
                          'type': 6, 'type_name': 'double precision'
                          }, {'expression': '"СПП_НЕжилая"', 'length': 0, 'name': 'СПП_НЕжилая', 'precision': 0,
                              'sub_type': 0, 'type': 6, 'type_name': 'double precision'
                              }, {'expression': '"Школа_емкость"', 'length': 0, 'name': 'Школа_емкость', 'precision': 0,
                                  'sub_type': 0, 'type': 2, 'type_name': 'integer'
                                  }, {'expression': '"ДОО_емкость"', 'length': 0, 'name': 'ДОО_емкость', 'precision': 0,
                                      'sub_type': 0, 'type': 2, 'type_name': 'integer'
                                      },
                         {'expression': '"Площадь_грн"', 'length': 0, 'name': 'Площадь_грн', 'precision': 0,
                          'sub_type': 0, 'type': 6, 'type_name': 'double precision'
                          },
                         {'expression': '"Плотность"', 'length': 0, 'name': 'Плотность', 'precision': 0, 'sub_type': 0,
                          'type': 6, 'type_name': 'double precision'
                          }, {'expression': '"Высотность"', 'length': 0, 'name': 'Высотность', 'precision': 0,
                              'sub_type': 0, 'type': 6, 'type_name': 'double precision'
                              }, {'expression': '"Примечание"', 'length': 254, 'name': 'Примечание', 'precision': 0,
                                  'sub_type': 0, 'type': 10, 'type_name': 'text'
                                  },
                         {'expression': '"t_from_contents"', 'length': 20, 'name': 't_from_contents', 'precision': 0,
                          'sub_type': 0, 'type': 10, 'type_name': 'text'
                          }]

        """ END script for reoarganiz """

        building_ex = {'building_ex': [['building_ex'], scr_bld_ex]}
        landscaping_ex = {'landscaping_ex': [['landscaping_ex'], scr_land_ex]}

        building = {'BUILDING': [['blds'], scr_bld]}
        building_pr = {'total_building_pr': [[
            'arch_building_pr',
            'kr_building_pr',
            'krt_building_pr',
            'kvm_building_pr',
            'ppt_building_pr',
            'ppt_ren_building_pr',
            'ppt_tpu_building_pr',
            'pzz_building'
        ], scr_bld_pr]
        }
        landscaping_pr = {'total_a_landscaping_pr': [['lands_pr'], scr_land_pr]}
        ld_terr = {'ld_region': [['ld_region'], scr_ld_terr]}
        road = {'ROAD_POLY': [['rd'], scr_road]}
        terr_razvitie = {'total_terr_razvitie': [[
            'arch_terr_razvitie',
            'kr_terr_razvitie',
            'krt_terr_razvitie',
            'kvm_terr_razvitie',
            'ppt_ren_terr_razvitie',
            'ppt_terr_razvitie',
            'ppt_tpu_terr_razvitie',
            'pzz_terr_razvitie'
        ], scr_terr_razv]
        }

        if self.checkBox.isChecked():
            all_lsr = [building, building_pr, landscaping_pr, ld_terr, road, terr_razvitie, landscaping_ex, building_ex]
        elif not self.checkBox.isChecked():
            all_lsr = [building, building_pr, landscaping_pr, ld_terr, road, terr_razvitie]

        # all_lsr = [building, building_pr, landscaping_pr, ld_terr, road, terr_razvitie]
        # all_lsr = [building_pr, landscaping_pr, ld_terr]

        # выбираем по пересечению с геометрией g и объединяем
        rslt_lrs = []
        for lst in all_lsr:
            # print(f"name {list(lst)[0]} lr_list {list(lst.values())[0][0]} SCR {list(lst.values())[0][1]}")
            # rslt_lrs.append(self.select_by_geom_and_merge(g, list(lst)[0], list(lst.values())[0]))
            rslt_lrs.append(self.select_by_geom_and_merge(
                g,
                list(lst)[0],
                list(lst.values())[0][0],
                list(lst.values())[0][1]))

        crs_apu = QgsCoordinateReferenceSystem()
        crs_apu.createFromProj4(APU_SRC)
        try:
            for tmp_lr in rslt_lrs:
                tmp_lr.setCrs(crs_apu)

        except:
            # logging.info(f"STROKA 463 \nNAME_LR: {tmp_lr}  \nLIST_LRS{rslt_lrs}")
            pass

        # if self.checkBox.isChecked():
        #     for tmp_lr in rslt_lrs:
        #         # tmp_lr.setCrs(crs_apu)
        #         QgsProject.instance().addMapLayer(tmp_lr)

        pth = self.filenameEdit.text()
        self.pack_lrs(pth, rslt_lrs)

        # msg = f"СОХРАНИЛИ GPKG: {pth}"
        # QMessageBox.warning(self, 'Info!', msg)


        # инициируем клас из другого модуля дабы не писать функции в этом листинге
        self.mrgp_panels = mrgp_panels.mrgp_panels(self.iface)
        folder_path = os.path.dirname(os.path.abspath(pth))
        self.mrgp_panels.dir_path = folder_path  # получаем путь куда сохраняем результаты
        self.mrgp_panels.displaye_custom_message_bar(title='MSG', message=f'Результаты сохранены - {folder_path}')
